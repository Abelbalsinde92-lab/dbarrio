-- ════════════════════════════════════════
-- dbarrio v2.0 — Setup SQL
-- Ejecutar en Supabase SQL Editor (nuevo proyecto)
-- ════════════════════════════════════════

-- ── TABLAS ──────────────────────────────

create table admins (
  id         bigint primary key generated always as identity,
  created_at timestamptz default now(),
  auth_uid   uuid references auth.users(id) on delete cascade,
  tag        text
);

create table socios (
  id                bigint primary key generated always as identity,
  created_at        timestamptz default now(),
  updated_at        timestamptz default now(),
  nombre            text not null,
  telefono          text,
  zona              text,
  especialidad      text,
  email             text,
  auth_uid          uuid references auth.users(id) on delete set null,
  comision          numeric default 15,
  deuda             numeric default 0,
  trabajos          integer default 0,
  rating_avg        numeric default 0,
  rating_count      integer default 0,
  admitido          boolean default false,
  estado_socio      text default 'pendiente',
  motivo_baja       text
);

create table solicitudes (
  id                      bigint primary key generated always as identity,
  created_at              timestamptz default now(),
  fecha_ts                timestamptz default now(),
  cliente                 text not null,
  telefono                text not null,
  municipio               text,
  direccion               text,
  servicio                text,
  detalles                text,
  estado                  text default 'pendiente',
  sub_estado              text,
  socio_asignado          bigint references socios(id) on delete set null,
  monto                   numeric,
  nota_admin              text,
  nota_socio              text,
  motivo_rechazo          text,
  solicita_cierre         boolean default false,
  valoracion              integer,
  valoracion_ts           timestamptz,
  fecha_fin               timestamptz,
  consent_privacidad      boolean default false,
  consent_privacidad_ts   timestamptz,
  consent_contacto        boolean default false,
  consent_contacto_ts     timestamptz,
  consent_texto           text
);

create table movimientos (
  id           bigint primary key generated always as identity,
  created_at   timestamptz default now(),
  socio_id     bigint references socios(id) on delete cascade,
  solicitud_id bigint references solicitudes(id) on delete set null,
  tipo         text not null,
  monto        numeric not null,
  nota         text
);

create table garantias (
  id                   bigint primary key generated always as identity,
  created_at           timestamptz default now(),
  recibo               text,
  telefono             text,
  falla                text,
  estado               text default 'pendiente',
  consent_privacidad   boolean default false,
  consent_privacidad_ts timestamptz,
  consent_texto        text
);

create table quejas (
  id                   bigint primary key generated always as identity,
  created_at           timestamptz default now(),
  telefono             text,
  codigo_servicio      text,
  mensaje              text,
  socio_id             bigint references socios(id) on delete set null,
  estado               text default 'pendiente',
  consent_privacidad   boolean default false,
  consent_privacidad_ts timestamptz,
  consent_texto        text
);

-- ── FUNCIONES RLS ───────────────────────

create or replace function is_admin()
returns boolean language sql security definer stable as $$
  select exists (select 1 from admins where auth_uid = auth.uid());
$$;

create or replace function is_socio()
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from socios
    where auth_uid = auth.uid() and admitido = true and estado_socio = 'activo'
  );
$$;

create or replace function get_socio_id()
returns bigint language sql security definer stable as $$
  select id from socios
  where auth_uid = auth.uid() and admitido = true and estado_socio = 'activo'
  limit 1;
$$;

-- ── RLS ─────────────────────────────────

alter table admins       enable row level security;
alter table socios       enable row level security;
alter table solicitudes  enable row level security;
alter table movimientos  enable row level security;
alter table garantias    enable row level security;
alter table quejas       enable row level security;

-- admins
create policy "admins_self" on admins for select using (auth.uid() = auth_uid);

-- socios
create policy "socios_admin_all"    on socios for all    using (is_admin());
create policy "socios_self_select"  on socios for select using (auth.uid() = auth_uid);
create policy "socios_self_update"  on socios for update using (auth.uid() = auth_uid);
create policy "socios_public_insert" on socios for insert with check (admitido = false and estado_socio = 'pendiente');

-- solicitudes
create policy "sol_admin_all"      on solicitudes for all    using (is_admin());
create policy "sol_public_insert"  on solicitudes for insert with check (true);
create policy "sol_public_select"  on solicitudes for select using (true);
create policy "sol_public_update"  on solicitudes for update using (true);
create policy "sol_socio_select"   on solicitudes for select
  using (is_admin() or (is_socio() and socio_asignado = get_socio_id()));
create policy "sol_socio_update"   on solicitudes for update
  using (is_admin() or (is_socio() and socio_asignado = get_socio_id()));

-- movimientos
create policy "mov_admin_all"    on movimientos for all    using (is_admin());
create policy "mov_socio_select" on movimientos for select
  using (is_admin() or (is_socio() and socio_id = get_socio_id()));

-- garantias / quejas
create policy "gar_admin_all"   on garantias for all    using (is_admin());
create policy "gar_pub_insert"  on garantias for insert with check (true);
create policy "que_admin_all"   on quejas    for all    using (is_admin());
create policy "que_pub_insert"  on quejas    for insert with check (true);

-- ── PRIMER ADMIN (ejecutar DESPUÉS de crear cuenta) ──
-- Reemplaza TU_AUTH_UUID con el UUID del usuario admin
-- insert into admins (auth_uid, tag) values ('TU_AUTH_UUID', 'admin');

